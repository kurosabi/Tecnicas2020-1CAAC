#ifndef FUNCIONESCC_H_
#define FUNCIONESCC_H_
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <iostream>

using namespace std;

typedef enum{
	RESTAURANTE, ROPA, CALZADO, JOYERIA, VARIEDADES
}tipoDeLocales;


//Local 
typedef struct Local{
	char nombreLocal[35];
	char tipoLocal[35];
	tipoDeLocales tipoLocales; 
	int idLocal; // Calculado automaticamente por su programa
	int pisoLocal;
	int numLocalxPiso;
	int disponible;
	int cantidadMercancia;
	// Completelo con lo que quiera
} local_t;


local_t **reservaCC(int numPisos, int numLocales);

void inicializacionMatriz(local_t **centroComercial, int numPisos, int numLocales);

void crearNuevoLocal(local_t **centroComercial);

void modificarInfoLocal(local_t **centroComercial);

void eliminarLocales(local_t **centroComercial);

void infoCC(local_t **centroComercial, int numPisos, int numLocales);

void infoLocal(local_t **centroComercial);

/*Agregar las funciones que necesite para satisfacer los requerimientos */
//void mostrarLocal(local_t ** centroComercial, int numPiso, int numLocalxPiso, int numPisos, int numLocalesxPiso);


#endif /* FUNCIONESCC_H_ */