#include "FuncionesCC.h"
/* Funcion de ejemplo que imprimiria la informacion de un local */
/*
void mostrarLocal(local_t ** centroComercial, int numPiso,
		int numLocalxPiso, int numPisos, int numLocalesxPiso) {
	
	//Se valida si el numero ingresado esta en el rango
	if(numPiso<=numLocalxPiso && numLocalxPiso <= numLocalesxPiso)
	{
		printf("Nombre local : %s", centroComercial[numPiso][numLocalxPiso].nombreLocal);
		printf("Numero local : %d ", centroComercial[numPiso][numLocalxPiso].numeroLocal);
	}
	//TODO completarlo con los datos que le sirvan en su caso
}
*/



/*
	Esta funcion reserva memoria dinamicamente para la matriz
	que representa el centro comercial, los tamaños son 
	de acuerdo al gusto del usuario.
*/
local_t **reservaCC(int numPisos, int numLocales){

	int i;

	local_t **centroComercial = (local_t**)malloc(sizeof(local_t**)*numPisos);

	if(centroComercial != NULL){

		for(i = 0; i < numPisos; i++){

			centroComercial[i] = (local_t*)malloc(sizeof(local_t*)*numLocales);

			if(centroComercial[i] == NULL){

				throw logic_error("error al crear el centro comercial\n");
			}
		}

		printf("Se ha creado satisfactoriamente el centro comercial\n\n");
	}
	else{

		throw logic_error("error al crear el centro comercial\n");
	}

	return centroComercial;
}


/*
	Esta funcion inicializa la matriz con todos los locales en 1, esto
	quiere decir que todos los locales en un principio estan disponibles.
	En este escenario el 1 significa que el local esta disponible y el
	0 por lo contrario significa que no esta disponible.
*/
void inicializacionMatriz(local_t **centroComercial, int numPisos, int numLocales){

	int i, j;

	for(i = 0; i < numPisos; i++){
		for(j = 0; j < numLocales; j++){

			centroComercial[i][j].disponible = 1;
		}
	}
}


/*
	Esta funcion crea un nuevo local en el centro comercial pero solo
	si el local se encuentra disponible, en caso de que no este disponible
	la funcion le va a pedir al usuario que intente con otro local.	
*/
void crearNuevoLocal(local_t **centroComercial){

	int i, j, piso, local, id, temp;
	int encontroDisponible = 0;
	srand(time(NULL));

	FILE *archivo;

	archivo = fopen("Locales.txt", "a");

	while(!encontroDisponible){


		printf("Ingrese el piso del local: ");
		scanf("%d", &piso);
		printf("\n");
		printf("Ingrese el numero del local: ");
		scanf("%d", &local);
		printf("\n");

		piso = piso - 1;
		local = local - 1;

		if(centroComercial[piso][local].disponible == 1){

			id = rand()%101;
			centroComercial[piso][local].idLocal = id;
			fprintf(archivo, "%d     ", centroComercial[piso][local].idLocal);

			printf("Ingrese un nombre para el local: ");
			scanf("%35s", &centroComercial[piso][local].nombreLocal);
			fprintf(archivo, "%s     ", centroComercial[piso][local].nombreLocal);
			printf("\n");
			printf("Ingrese un tipo de mercado del local: ");
			scanf("%35s", &centroComercial[piso][local].tipoLocal);
			fprintf(archivo, "%s     ", centroComercial[piso][local].tipoLocal);
			printf("\n");

			/*
			printf("Seleccione el tipo de local que desea.\n");

			//REVISAR DESDE AQUI!!!!!!!!!!!!!!!REVISAR DESDE AQUI!!!!!!!!!!!!!!!!!!!!
			
			do{

				printf("1. Restaurante\n");
				printf("2. Ropa\n");
				printf("3. Calzado\n");
				printf("4. Joyeria\n");
				printf("5. Variedades\n");
				printf("6. Salir\n");
				printf("\n");
		    	printf("Opcion: ");
				scanf("%d", &temp);
				printf("\n");

				switch(temp){

					case RESTAURANTE:

						centroComercial[piso][local].tipoLocales = RESTAURANTE;
						printf("El tipo de local seleccionado a sido RESTAURANTE\n");
						break;

					case ROPA:

						centroComercial[piso][local].tipoLocales = ROPA;
						printf("El tipo de local seleccionado a sido ROPA\n");
						break;

					case CALZADO:

						centroComercial[piso][local].tipoLocales = CALZADO;
						printf("El tipo de local seleccionado a sido CALZADO\n");
						break;

					case JOYERIA:

						centroComercial[piso][local].tipoLocales = JOYERIA;
						printf("El tipo de local seleccionado a sido JOYERIA\n");
						break;

					case VARIEDADES:

						centroComercial[piso][local].tipoLocales = VARIEDADES;
						printf("El tipo de local seleccionado a sido VARIEDADES\n");
						break;

					case 6:

						break;

					default:

		                throw logic_error("Opcion invalida\n");
				}
			} while(temp != 6);
			//REVISAR HASTA AQUI!!!!!!!!!!!!!!!!!!!!! REVISAR HASTA AQUI !!!!!!!!!!!!!!!
			*/

			/*
			printf("Escriba el tipo de mercado que escogio anteriormente: ");
			scanf("%35s", &centroComercial[piso][local].tipoLocal);
			fprintf(archivo, "%s     ", centroComercial[piso][local].tipoLocal);
			printf("\n");
			*/


			printf("Ingrese la cantidad de mercancia con la que va a empezar el local: ");
			scanf("%d", &centroComercial[piso][local].cantidadMercancia);
			fprintf(archivo, "%d     \n", centroComercial[piso][local].cantidadMercancia);
			printf("\n\n");

			centroComercial[piso][local].pisoLocal = piso + 1;
			centroComercial[piso][local].numLocalxPiso = local + 1;	
			centroComercial[piso][local].disponible = 0;

			encontroDisponible = 1;		
		}

		else{
			throw logic_error("Este local no se encuentra disponible, intente con un local diferente.\n\n");
		}
	}

	printf("Se ha creado el local satisfactoriamente con los siguentes datos:\n\n");
	printf("Nombre del local: %s\n", centroComercial[piso][local].nombreLocal);
	printf("ID del local: %d\n", centroComercial[piso][local].idLocal);
	printf("El tipo de mercado es: %s\n", centroComercial[piso][local].tipoLocal);
	printf("La cantidad de mercancia que hay en el local es: %d\n", centroComercial[piso][local].cantidadMercancia);
	printf("Piso: %d\n", piso + 1);
	printf("Numero del local: %d\n", local + 1);
	printf("\n\n");

	fclose(archivo);
}


/*
	Esta funcion modifica alguna informacion del local que el usuario
	desee, a exepcion del id, puesto que este identificador es unico.	
*/
void modificarInfoLocal(local_t **centroComercial){

	int temp, piso, local;

	printf("Ingrese el piso del local que quiere modificar: ");
	scanf("%d", &piso);
	printf("\n");
	printf("Ingrese el numero del local que quiere modificar: ");
	scanf("%d", &local);
	printf("\n");

	piso = piso - 1;
	local = local - 1;

	do{

		printf("1. Modificar el nombre del local\n");
		printf("2. Modificar el tipo de mercado del local\n");
		printf("3. Cambiar la cantidad de mercancia\n");
		printf("4. Terminar\n");
		printf("\n");
    	printf("Opcion: ");
		scanf("%d", &temp);
		printf("\n");

		switch(temp){

			case 1:

				printf("Nombre actual del local: %s\n", centroComercial[piso][local].nombreLocal);
				printf("Ingrese el nuevo nombre del local: ");
				scanf("%35s", &centroComercial[piso][local].nombreLocal);
				printf("\n");
				printf("Nuevo nombre del local: %s\n", centroComercial[piso][local].nombreLocal);
				break;

			case 2:

				printf("Tipo de mercado actual del local: %s\n", centroComercial[piso][local].tipoLocal);
				printf("Ingrese el nuevo tipo de mercado del local: ");
				scanf("%35s", &centroComercial[piso][local].tipoLocal);
				printf("\n");
				printf("Nuevo tipo de mercado del local: %s\n", centroComercial[piso][local].tipoLocal);
				break;

			case 3:

				printf("Cantidad de mercancia actual: %d\n", centroComercial[piso][local].cantidadMercancia);
				printf("Ingrese la nueva cantidad de mercancia del local: ");
				scanf("%d", &centroComercial[piso][local].cantidadMercancia);
				printf("\n");
				printf("Nueva cantidad de mercancia del local: %d\n", centroComercial[piso][local].cantidadMercancia);
				break;

			case 4:

				break;

			default:

                throw logic_error("Opcion invalida\n");
		}
	} while(temp != 4);
}


/*
	Esta funcion elimina un local del centro comercial, es decir, que 
	el local pasa a estar disponible.		
*/
void eliminarLocales(local_t **centroComercial){

	int temp, piso, local;

	printf("Ingrese el piso del local que quiere eliminar: ");
	scanf("%d", &piso);
	printf("\n");
	printf("Ingrese el numero del local que quiere eliminar: ");
	scanf("%d", &local);
	printf("\n");

	piso = piso - 1;
	local = local - 1;

	centroComercial[piso][local].disponible = 1;
}


/*
	Esta funcion brinda informacion de algun local en especifico
	que el usuario desee conocer.	
*/
void infoLocal(local_t **centroComercial){

	int temp, piso, local;

	printf("Ingrese el piso del local del que quiera informacion: ");
	scanf("%d", &piso);
	printf("\n");
	printf("Ingrese el numero del local del que quiera informacion: ");
	scanf("%d", &local);
	printf("\n");

	piso = piso - 1;
	local = local - 1;

	do{

		printf("1. Nombre del local\n");
		printf("2. ID del local\n");
		printf("3. Tipo de mercado del local\n");
		printf("4. Cantidad de mercancia del local\n");
		printf("5. Terminar\n");
		printf("\n");
    	printf("Opcion: ");
		scanf("%d", &temp);
		printf("\n");

		switch(temp){

			case 1:

				printf("El nombre del local es: %s\n", centroComercial[piso][local].nombreLocal);
				break;

			case 2:

				printf("El ID del local es: %d\n", centroComercial[piso][local].idLocal);
				break;

			case 3:

				printf("El tipo de mercado del local es: %s\n", centroComercial[piso][local].tipoLocal);
				break;

			case 4:

				printf("La cantidad de mercancia que hay en el local es: %d\n", centroComercial[piso][local].cantidadMercancia);
				break;

			case 5:

				break;

			default:

                throw logic_error("Opcion invalida\n");
		}		
	} while(temp != 5);
}


void infoOrdenada(local_t **centroComercial, int numPisos, int numLocales){

	int temp, i, piso, locales;

	do{
		
		printf("*****TODAS LAS OPCIONES SON POR PISO*****\n\n");
		printf("1. Visualizar los locales ordenados por mercancia\n");
		printf("2. Visualizar los locales ordenados por id\n");
		printf("3. Visualizar los locales por numero de local\n");
		printf("4. Visualizar los locales por piso\n");
		printf("5. Terminar\n");
		printf("\n");
		printf("Opcion: ");
		scanf("%d", &temp);
		printf("\n");
		
		switch(temp){

			case 1:

				printf("Ingrese el piso que quiere ver ordenado: ");
				scanf("%d", &piso);
				printf("\n");
				printf("Ingrese la cantidad de locales que hay en el piso: ");
				scanf("%d", &locales);
				printf("\n");

				ordenarMercancia(centroComercial, piso, locales);

				break;

			case 2:

				printf("Ingrese el piso que quiere ver ordenado: ");
				scanf("%d", &piso);
				printf("\n");
				printf("Ingrese la cantidad de locales que hay en el piso: ");
				scanf("%d", &locales);
				printf("\n");

				ordenarID(centroComercial, piso, locales);

				break;

			case 3:

				printf("Ingrese el piso que quiere ver ordenado: ");
				scanf("%d", &piso);
				printf("\n");
				printf("Ingrese la cantidad de locales que hay en el piso: ");
				scanf("%d", &locales);
				printf("\n");

				ordenarLocal(centroComercial, piso, locales);

				break;

			case 4:

				ordenarPiso(centroComercial, numPisos, numLocales);

				break;

			case 5:

				break;

			default:
				throw logic_error("Opcion invalida\n");
		}
	}while(temp != 5);

	printf("\n\n");
}

/*
	Esta funcion brinda informacion del centro comercial que este
	disponible al usuario.	
*/
void infoCC(local_t **centroComercial, int numPisos, int numLocales){

	int temp;

	do{

		printf("1. Saber el numero de pisos que hay en el centro comercial\n");
		printf("2. Saber el numero de locales que hay por piso en el centro comercial\n");
		printf("3. Informacion de algun local en especifico\n");
		printf("4. Visualizar alguna informacion del centro comercial ordenada.\n");
		printf("5. Terminar\n");
		printf("\n");
    	printf("Opcion: ");
		scanf("%d", &temp);
		printf("\n");

		switch(temp){

			case 1:

				printf("Numero de pisos totales que hay en el centro comercial: %d\n", numPisos);
				break;

			case 2:

				printf("Numero de locales totales que hay por piso en el centro comercial: %d\n", numLocales);
				break;

			case 3:

				infoLocal(centroComercial);
				break;

			case 4:

				infoOrdenada(centroComercial, numPisos, numLocales);
				break;

			case 5:

				break;

			default:

                throw logic_error("Opcion invalida\n");
		}
	} while (temp != 5);
}


/*
	Apartir de aqui se definen todos los algoritmos de ordenamientos
	insertion, selection y merge sort.
*/

void insertionSort(int arr[], int n){

	int i, key, j;

	for(i = 1; i < n; i++){ 
		
		key = arr[i]; 
		j = i - 1; 

		while(j >= 0 && arr[j] > key){

			arr[j + 1] = arr[j]; 
			j = j - 1; 
		}

		arr[j + 1] = key; 
	} 
}


void swap(int *xp, int *yp){ 

	int temp = *xp; 
	*xp = *yp; 
	*yp = temp; 
} 


void selectionSort(int arr[], int n){ 

	int i, j, min_idx; 

	for (i = 0; i < n-1; i++) 
	{ 

		min_idx = i; 
		for (j = i+1; j < n; j++) 
		if (arr[j] < arr[min_idx]) 
			min_idx = j; 

		swap(&arr[min_idx], &arr[i]); 
	} 
}


void merge(int arr[], int l, int m, int r){ 

	int i, j, k; 
	int n1 = m - l + 1; 
	int n2 = r - m; 

	int L[n1], R[n2]; 

	for (i = 0; i < n1; i++){

		L[i] = arr[l + i];
	}

	for (j = 0; j < n2; j++){

		R[j] = arr[m + 1+ j]; 
	}

	i = 0; 
	j = 0; 
	k = l;
	
	while (i < n1 && j < n2){ 

		if(L[i] <= R[j]){ 

			arr[k] = L[i]; 
			i++; 
		}

		else{

			arr[k] = R[j]; 
			j++; 
		} 

		k++; 
	} 

	while(i < n1){ 

		arr[k] = L[i]; 
		i++; 
		k++; 
	} 

	while(j < n2){ 

		arr[k] = R[j]; 
		j++; 
		k++; 
	} 
} 


void mergeSort(int arr[], int l, int r){ 

	if(l < r){ 

		int m = l+(r-l)/2; 

		mergeSort(arr, l, m); 
		mergeSort(arr, m+1, r); 

		merge(arr, l, m, r); 
	} 
}


void quickSort(int *arr, int izquierda, int derecha){

	int i = izquierda;
	int j = derecha;
	int temp;
	int p = arr[(izquierda + derecha) / 2];

	while(i <= j){

		while(arr[i] < p){
			i++;
		}
		while(arr[j] > p){
			j++;
		}

		if(i <= j){
			temp = arr[i];
			arr[i] = arr[j];
			arr[j] = temp;
			i++;
			j--;
		}
	}

	if(izquierda < j){
		quickSort(arr, izquierda, j);
		if(i < derecha){
			quickSort(arr, i, derecha);
		}
	}
}
// Aqui termina la definicion de todos los algoritmos de ordenamiento


void ordenarMercancia(local_t **centroComercial, int numPiso, int Locales){

	int temp, i;
	int aux[Locales];

	FILE *archivo;

	archivo = fopen("Listado.txt", "w");

	for(i = 0; i < Locales; i++){

		if(centroComercial[numPiso][i].disponible == 0){

			aux[i] = centroComercial[numPiso][i].cantidadMercancia;
		}

		else{
			aux[i] = 0;
		}
	}

	int n = sizeof(aux) / sizeof(aux[0]);

	insertionSort(aux, n);

	for(i = 0; i < Locales; i++){

		fprintf(archivo, "%d\n", aux[i]);
	}

	printf("Revisar el archivo Listado, ahi se pueden ver los locales ordenados por mercancia\n");
	printf("ADVERTENCIA: Solo aparece la cantidad de mercancia.\n");

	fclose(archivo);
}


void ordenarID(local_t **centroComercial, int numPiso, int Locales){

	int temp, i;
	int aux[Locales];

	FILE *archivo;

	archivo = fopen("Listado.txt", "w");

	for(i = 0; i < Locales; i++){

		if(centroComercial[numPiso][i].disponible == 0){

			aux[i] = centroComercial[numPiso][i].idLocal;
		}

		else{
			aux[i] = 0;
		}
	}

	int n = sizeof(aux) / sizeof(aux[0]);

	selectionSort(aux, n);

	for(i = 0; i < Locales; i++){

		fprintf(archivo, "%d\n", aux[i]);
	}

	printf("Revisar el archivo Listado, ahi se pueden ver los locales ordenados por ID\n");
	printf("ADVERTENCIA: Solo aparece el ID del local.\n");

	fclose(archivo);
}


void ordenarLocal(local_t **centroComercial, int numPiso, int Locales){

	int temp, i;
	int aux[Locales];

	FILE *archivo;

	archivo = fopen("Listado.txt", "w");

	for(i = 0; i < Locales; i++){

		if(centroComercial[numPiso][i].disponible == 0){

			aux[i] = centroComercial[numPiso][i].numLocalxPiso;
		}

		else{
			aux[i] = 0;
		}
	}

	int n = sizeof(aux) / sizeof(aux[0]);

	mergeSort(aux, 0, n - 1);

	for(i = 0; i < Locales; i++){

		fprintf(archivo, "%d\n", aux[i]);
	}

	printf("Revisar el archivo Listado, ahi se pueden ver los locales ordenados por numero de local\n");
	printf("ADVERTENCIA: Solo aparece el numero del local.\n");

	fclose(archivo);
}

//¡¡¡¡¡¡¡REVISAR!!!!!!
void ordenarPiso(local_t **centroComercial, int numPiso, int Locales){

	int temp, i, j;
	int aux[Locales];

	FILE *archivo;

	archivo = fopen("Listado.txt", "w");

	for(i = 0; i < numPiso; i++){

		for(j = 0; j < Locales; j++){

			if(centroComercial[i][j].disponible == 0){

				aux[i] = centroComercial[i][j].pisoLocal;
			}
			else{
				aux[i] = 0;
			}
		}
	}

	quickSort(aux, 0, Locales - 1);

	for(i = 0; i < Locales; i++){

		fprintf(archivo, "%d\n", aux[i]);
	}

	printf("Revisar el archivo Listado, ahi se pueden ver los locales ordenados por piso\n");
	printf("ADVERTENCIA: Solo aparece el piso del local.\n");

	fclose(archivo);
}