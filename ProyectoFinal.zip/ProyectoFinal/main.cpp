#include "FuncionesCC.h"
#include <stdio.h>
#include <iostream>

using namespace std;


int menu()
{

    int opcion = 0;

    printf(" Opciones  \n\n");
    printf("1. Crear un centro Comercial\n");
    printf("2. Crear un nuevo local en el centro Comercial\n");
    printf("3. Consultar informacion del centro comercial\n");
    printf("4. Modificar la informacion de un local\n");
    printf("5. Eliminar un Local (este local pasara a estar disponible)\n");
    printf("6. Salir\n");
    printf("\n");
    printf("Opcion: ");
    scanf("%d", &opcion);
    printf("\n");

    return opcion;
}


int main(){

	local_t **centroComercial;
	int i, j, numPisos, numLocales, option;

    do
    {
        try{
            option = menu();
            switch (option){

                case 1:

            		printf("Ingrese el numero de pisos para el centro comercial:");
    				scanf("%d", &numPisos);
    				printf("\n");
    				printf("Ingrese el numero de locales para el centro comercial:");
    				scanf("%d", &numLocales);
    				printf("\n");

                    centroComercial = reservaCC(numPisos, numLocales);
                    inicializacionMatriz(centroComercial, numPisos, numLocales);
                    break;

                case 2:

                	crearNuevoLocal(centroComercial);		
                	break;

                case 3:

                	infoCC(centroComercial, numPisos, numLocales);
                	break;

                case 4:

                	modificarInfoLocal(centroComercial);
                	break;

                case 5:

                	eliminarLocales(centroComercial);
                	break;

                case 6:
                    break;
                
                default:
                    throw logic_error("Opcion invalida\n");
                    
            }
        }

        catch(logic_error &e){
            printf("Este programa tiene el siguente erro de validacion: %s\n\n", e.what());
        }

    } while (option != 6);

    if(centroComercial != NULL){
        free(centroComercial);
    }
	
	return 0;
}